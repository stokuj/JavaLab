/**
 * Contains five classes for model and exceptions
 */
package pl.polsl.stasica.krystian.model;
