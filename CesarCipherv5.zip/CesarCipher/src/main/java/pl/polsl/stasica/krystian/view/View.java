
package pl.polsl.stasica.krystian.view;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

import pl.polsl.stasica.krystian.model.ShiftNotIntException;
import pl.polsl.stasica.krystian.model.EmptyFileNameException;
import pl.polsl.stasica.krystian.model.FileNotFoundErrorException;


import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/** 
 * Class holds basic information about input, output file names and shift value
 * Default values are allready set.
 * 
 * @author Krystian Stasica
 * @version 0.5
 */
public class View 
{
    // All testing variables are used to separate prototype of user interface from core program.    
    // Some funtion like printBasicInfo may be changed  into buttons
    
    
    // View uses Swing framework to display UI to user
    
    /**
     *  Main frame of program
     */
    private JFrame frame;
    
    /**
     *  Laber for input file
     */
    private JLabel inputLabel;
    
    /**
     *  Laber for output file
     */
    private JLabel outputLabel;
    
    /**
     *  Laber for shift
     */
    private JLabel shiftLabel;
    
    /**
     *  Textfield for input file
     */
    private JTextField inputTextfield;
    
    /**
     *  Textfield for output file
     */
    private JTextField outputTextfield;
    
    /**
     *  Textfield for shift
     */
    private JTextField shiftTextfield;
    
    /**
     *  Button to save input file
     */
    private JButton inputSaveButton;
    
    /**
     *  Button to save output file
     */
    private JButton outputSaveButton;
    
    /**
     *  Button to save shift
     */
    private JButton shiftSaveButton;
    
    /**
     *  Button to run core program
     */
    private JButton runApp;
    
    /**
     *  Button to exit
     */
    private JButton exit;
    
    /**
     * Metheod creates main window from definied elements
     * 
      @param title   program title
     */
    public View(String title) 
    {
        // FRAME
        frame = new JFrame(title);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 160);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // UI ELEMENTS
        inputLabel = new JLabel("Input :");
        outputLabel = new JLabel("Output :");
        shiftLabel = new JLabel("Shift :");
        
        inputTextfield = new JTextField();
        outputTextfield = new JTextField();
        shiftTextfield = new JTextField();
        
        inputSaveButton = new JButton("Save input");
        outputSaveButton = new JButton("Save output");
        shiftSaveButton = new JButton("Save shift");
        
        runApp = new JButton("START");
        exit = new JButton("EXIT!");
        
        // UI -> FRAME
        
        GroupLayout layout = new GroupLayout(frame.getContentPane());
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setHorizontalGroup(layout.createSequentialGroup()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(inputLabel)
          .addComponent(outputLabel).addComponent(shiftLabel))
                
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(inputTextfield)
          .addComponent(outputTextfield).addComponent(shiftTextfield))
                
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(inputSaveButton)
          .addComponent(outputSaveButton).addComponent(shiftSaveButton))
                
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(runApp)
          .addComponent(exit)));
        layout.setVerticalGroup(layout.createSequentialGroup()
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(inputLabel)
          .addComponent(inputTextfield).addComponent(inputSaveButton).addComponent(runApp))
                
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(shiftLabel)
          .addComponent(shiftTextfield).addComponent(shiftSaveButton).addComponent(runApp))
                
          .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(outputLabel)
          .addComponent(outputTextfield).addComponent(outputSaveButton).addComponent(exit)));
        layout.linkSize(SwingConstants.HORIZONTAL, inputSaveButton, outputSaveButton,shiftSaveButton);
        layout.linkSize(SwingConstants.HORIZONTAL, runApp, exit);
        frame.getContentPane().setLayout(layout);
    }
    

    /**
     * Return data from text field
     * 
      @return inputTextfield input that will be saved
     */
    public JTextField getInputTextfield() {
     return inputTextfield;
    }

    /**
     * Return data from text field
     * 
      @return outputTextfield output that will be saved
     */
    public JTextField getOutputTextfield() {
     return outputTextfield;
    }
    
    /**
     * Return data from text field
     * 
      @return shiftTextfield shift that will be saved
     */
    public JTextField getShiftTextfield() {
     return shiftTextfield;
    }
    
    /**
     * When button to save input is pressed
     * 
      @return inputSaveButton save action
     */
    public JButton getInputSaveButton() {
     return inputSaveButton;
    }

    /**
     * When button to save output is pressed
     * 
      @return outputSaveButton save action
     */
    public JButton getOutputSaveButton() {
     return outputSaveButton;
    }

    /**
     * When button to save shift is pressed
     * 
      @return shiftSaveButton save action
     */
    public JButton getShiftSaveButton() {
     return shiftSaveButton;
    }
    
    /**
     * When start button is pressed
     * 
      @return runApp start action
     */
    public JButton getStart() {
     return runApp;
    }

    /**
     * When exit button is pressed
     * 
      @return exit exit action
     */
    public JButton getExit() {
     return exit;
    }

////////////////////////////////////////////////////////////////////////////////
    /**
     * Method prints basic information for user.
     * 
     */
    public void basicInfo(){
        System.out.println("Wecome to Cesar Cipher program.\n");

        System.out.println("Program can take following arguments");
        System.out.println("or can ask user for input if no arguments are detected.\n");

        System.out.println("Use -o input.txt to enter input file name.");
        System.out.println("Use -i output.txt to enter output file name.");
        System.out.println("Use -s and intiger to set shift position.");
        System.out.println("For decodeing use negative shift.");
        System.out.println("-i infile.txt -o outfile.txt -s -3\n");
    }

   /**
     * Method taked input from user and return it to controller.
     *
     * @return name given input by user or default value
     * @throws pl.polsl.stasica.krystian.model.EmptyFileNameException when filename is empty
     */
    public String askForInput() throws EmptyFileNameException{

        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter your input file in txt format.");
        String name = sc.nextLine();

        if(name.equals(""))
        {   
            name = "infile.txt";
            sc.close();
            throw new EmptyFileNameException();
        }

        sc.close();
        return name;
    }
    
   /**
     * Method taked output from user and return it to controller.
     *
     * @return name given output by user or default value
     * @throws pl.polsl.stasica.krystian.model.EmptyFileNameException   when filename is empty
     */
    public String askForOutput() throws EmptyFileNameException{

        Scanner sc=new Scanner(System.in);
        System.out.println("Please enter your output file in txt format.");
        String name = sc.nextLine();

        if(name.equals(""))
        {   
            name = "outfile.txt";
            sc.close();
            throw new EmptyFileNameException();
        }
        sc.close();
        return name;
    }
    
    /**
     * Method taked shift from user and returns it to controller.
     *
     * @return name given shift by user or default value
     * @throws pl.polsl.stasica.krystian.model.ShiftNotIntException when shift is not int
     */
    public int askForShift() throws ShiftNotIntException  {   
        var tmp=0;

        System.out.println("Please enter your shift intiger.");
        Scanner sc=new Scanner(System.in);
        if(sc.hasNextInt())
            tmp=sc.nextInt();
        else
        {
            sc.close();
            throw new ShiftNotIntException();
        }

        sc.close();
        return tmp; // 3 is default value
    }
        
    /**
     * Method reads data from given file to an array list.
     * 
     * @param lines - array list of text rows
     * @param input - input file name
     * @throws pl.polsl.stasica.krystian.model.FileNotFoundErrorException when file was not found
     * @throws java.io.IOException throws when program can't locate path to file
     */
    public void readToFile(ArrayList<String> lines, String input ) throws FileNotFoundErrorException,IOException{
        
        File tempFile = new File(input);
        boolean exists = tempFile.exists();
        
        if(!exists)
            throw new FileNotFoundErrorException();
        
        Scanner scanner = new Scanner(Paths.get(input));

        // we read all the lines of the file
        while (scanner.hasNextLine()) 
        {
            lines.add(scanner.nextLine());
        }
    }     
    
    /**
     * Method loads data to given file from array list.
     * 
     * @param lines - array list of text rows
     * @param output - output file name
     * @throws pl.polsl.stasica.krystian.model.FileNotFoundErrorException   when filename was not found
     * @throws java.io.IOException throws when program can't locate path to file
     */
    public void loadToFile(ArrayList<String> lines, String output) throws FileNotFoundErrorException,IOException{
        
        File tempFile = new File(output);


        try (FileWriter file = new FileWriter(output)) 
        {
            for(String str: lines)
                file.write(str + System.lineSeparator());
        }
        boolean exists = tempFile.exists();
        if(!exists)
            throw new FileNotFoundErrorException();
        
        System.out.println("Successfully wrote to the file.");
    }
    
    
    /**
     * Method returns user choice about using default parameters.
     * 
     * @return returned boolean represents user intence
     */
    public boolean getUserChoiceAboutParameters(){
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Do you want to use default parameters?");    
        System.out.println("Write y/yes if so, or n/no if u want to input data.");
        
        boolean stopLoop = false;
        boolean userWantsDefaultParameters = false;
        
        while(!stopLoop)
        {
            String str= sc.nextLine();
            switch (str) {
                case "y":
                case "yes":
                    userWantsDefaultParameters = true;
                    stopLoop = true;
                    break;
                case "n":
                case "no":
                    userWantsDefaultParameters = false;
                    stopLoop = true;
                    break;
                default:
                    System.out.println("Wrong choice. Select again!");
                    break;
            }
        }
        sc.close();
        return userWantsDefaultParameters;
    }   
    
    
    /**
     * Method is printing in view, can be used in controller.
     * 
     * @param ex our exception that we want pass to method
     */
        public void displayException(Exception ex) 
        {
                MyInterface myInterface = (String text) -> {
                System.out.println(text);
            };

            myInterface.printIt(ex.getMessage());

        }
    
}
