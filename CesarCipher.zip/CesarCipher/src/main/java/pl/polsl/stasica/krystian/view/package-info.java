/**
 * Contains class for view
 */
package pl.polsl.stasica.krystian.view;
