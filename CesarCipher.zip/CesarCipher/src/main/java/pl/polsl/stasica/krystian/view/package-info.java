/**
 * Contains class for view and interface
 */
package pl.polsl.stasica.krystian.view;
